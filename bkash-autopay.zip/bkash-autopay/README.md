# AutoPay — bKash USSD auto-payment system (APK + Admin Panel)

```
Admin Panel (website)  <——— JSON API ———>  Android APK (your phone)
      |                                        |
  payment list (wallet,amount)              dials *247#, fills menus
      |                                        |       (Accessibility service)
  status: pending/done/failed  <—— report ———┘
```

You paste the payment list into the panel → the APK pays them one by one
through the *247# USSD menus → each result (success/fail + message) is
written back to the panel automatically.

## 1. Admin Panel (PHP + MySQL)

Any cheap PHP hosting works (cPanel, or localhost with XAMPP + ngrok/cloudflared).

1. Create a MySQL database and import `panel/db.sql` (phpMyAdmin -> Import).
2. Edit `panel/config.php`: DB credentials, `API_KEY`, `ADMIN_USER`, `ADMIN_PASS`.
3. Upload the `panel/` folder to your hosting, e.g. `https://yourdomain.com/panel/`.
4. Open `panel.php` in a browser, log in, paste your list:

   ```
   01700000000,200
   01811112222,500
   ```

   (one `wallet,amount` per line — or upload a CSV with the same columns)

## 2. Android APK

1. Install **Android Studio**, open the `android-app/` folder, let Gradle sync.
2. Build APK: Build -> Build APK(s) -> install on your phone.
3. On the phone (bKash SIM must be inside):
   - Settings -> Accessibility -> enable **AutoPay**.
   - Settings -> Apps -> AutoPay -> Battery -> **Unrestricted** (no optimization).
   - Developer options -> **Stay awake** (while charging) is recommended.
   - Keep the screen unlocked while it runs (USSD dialogs need an unlocked screen).
4. Open the app, enter:
   - **Panel URL** = `https://yourdomain.com/panel`
   - **API key** = the same `API_KEY` from `config.php`
   - **PIN** = your bKash PIN
5. Press **Start**. Watch the log + the panel status change to `done` / `failed`.

## 3. USSD flow it performs (verified against a real *247# session)

`dial *247#` -> `1` (Send Money) -> wallet number -> amount -> **reference** (auto = payment ID from the panel) -> PIN -> auto-press `OK` on the success screen

> Your list can use `wallet-amount` or `wallet,amount`, one per line:
>
> ```
> 01719554634-1000
> 01763636365-3500
> 01636353655-500
> ```

Menu changed? Edit the steps in `PayService.kt` -> `PayEngine.start(listOf(...))`.

## 4. Safety / warnings (read!)

- This drives bKash through USSD automation. It **violates bKash terms of use**;
  bKash can flag/limit/ban the wallet. Use a wallet you can afford to lose,
  keep volumes low, keep the built-in random delays.
- **Test with Tk 10 first**, and watch the first few payments manually.
- Your PIN lives in the app's private storage. Never share backups/screenshots
  of the phone while the PIN field is filled.
- Change `API_KEY` and `ADMIN_PASS` before going online. Use HTTPS for the panel.
- If payments fail with "session busy" errors, increase the pause in
  `PayService.kt` (`delay((8000..20000)...)`).
- For real business volume, use the official bKash Disbursement (Payout) API instead.
