<?php
require __DIR__ . '/config.php';
header('Content-Type: application/json');

$key = $_SERVER['HTTP_X_API_KEY'] ?? ($_GET['key'] ?? '');
if (!is_string($key) || !hash_equals(API_KEY, $key)) {
    http_response_code(401);
    echo json_encode(['error' => 'bad_api_key']);
    exit;
}

$action = $_GET['action'] ?? '';

if ($action === 'ping') {
    echo json_encode(['ok' => true, 'time' => date('c')]);
    exit;
}

if ($action === 'next') {
    // grab the oldest pending payment and lock it
    $pdo->beginTransaction();
    $row = $pdo->query(
        "SELECT id, wallet, amount FROM payments
         WHERE status='pending' ORDER BY id ASC LIMIT 1 FOR UPDATE"
    )->fetch();
    if ($row) {
        $pdo->prepare("UPDATE payments SET status='processing' WHERE id=?")
            ->execute([$row['id']]);
    }
    $pdo->commit();
    echo json_encode($row ?: ['none' => true]);
    exit;
}

if ($action === 'report') {
    $in = json_decode(file_get_contents('php://input'), true) ?: [];
    $id  = (int)($in['id'] ?? 0);
    $ok  = !empty($in['success']);
    $msg = substr((string)($in['message'] ?? ''), 0, 500);
    $pdo->prepare("UPDATE payments SET status=?, result=? WHERE id=?")
        ->execute([$ok ? 'done' : 'failed', $msg, $id]);
    echo json_encode(['ok' => true]);
    exit;
}

http_response_code(404);
echo json_encode(['error' => 'unknown_action']);
