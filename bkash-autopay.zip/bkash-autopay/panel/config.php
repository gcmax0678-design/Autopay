<?php
// ================== EDIT THESE ==================
define('DB_HOST', 'localhost');
define('DB_NAME', 'autopay');
define('DB_USER', 'root');
define('DB_PASS', '');
define('API_KEY', 'CHANGE_ME_LONG_RANDOM_STRING_123456789');
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', 'CHANGE_ME_STRONG_PASSWORD');
// ================================================

if (session_status() === PHP_SESSION_NONE) session_start();
$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);
