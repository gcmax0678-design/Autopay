<?php
require __DIR__ . '/config.php';

function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES); }

function page_top($title){
    echo "<!doctype html><html><head><meta charset='utf-8'>
    <meta name='viewport' content='width=device-width,initial-scale=1'>
    <title>".e($title)."</title>
    <style>
    body{font-family:Arial,Helvetica,sans-serif;background:#0f172a;color:#e2e8f0;max-width:960px;margin:20px auto;padding:0 12px}
    input,textarea{background:#1e293b;color:#e2e8f0;border:1px solid #334155;border-radius:6px;padding:8px;width:100%;box-sizing:border-box}
    button{background:#2563eb;color:#fff;border:0;border-radius:6px;padding:8px 16px;cursor:pointer}
    a{color:#60a5fa;text-decoration:none}
    table{width:100%;border-collapse:collapse;margin-top:12px}
    th,td{border:1px solid #334155;padding:6px;font-size:13px;vertical-align:top}
    th{background:#1e293b;text-align:left}
    .pill{padding:2px 8px;border-radius:10px;font-size:12px;color:#fff}
    .pending{background:#854d0e}.processing{background:#1d4ed8}.done{background:#15803d}.failed{background:#b91c1c}
    .nav{margin-bottom:16px}
    </style></head><body>";
}

function page_bottom(){ echo "</body></html>"; }

if (isset($_GET['logout'])) { unset($_SESSION['admin']); header('Location: ?login'); exit; }

// ---------- login ----------
if (isset($_GET['login'])) {
    $err = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (hash_equals(ADMIN_USER, (string)($_POST['u'] ?? '')) &&
            hash_equals(ADMIN_PASS, (string)($_POST['p'] ?? ''))) {
            session_regenerate_id(true);
            $_SESSION['admin'] = 1;
            header('Location: ?');
            exit;
        }
        $err = 'Wrong username or password';
    }
    page_top('Login');
    echo "<h2>AutoPay Admin</h2><p style='color:#f87171'>".e($err)."</p>
    <form method='post'>
      <input name='u' placeholder='Username' required><br><br>
      <input type='password' name='p' placeholder='Password' required><br><br>
      <button>Login</button>
    </form>";
    page_bottom(); exit;
}

if (empty($_SESSION['admin'])) { header('Location: ?login'); exit; }

$msg = '';

// ---------- add list ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_text'])) {
    $ins = $pdo->prepare("INSERT INTO payments(wallet, amount) VALUES(?,?)");
    $count = 0;
    foreach (preg_split('/\r?\n/', (string)$_POST['list']) as $ln) {
        if (preg_match('/(01\d{9})\D+(\d+(?:\.\d{1,2})?)/', $ln, $m)) {
            $ins->execute([$m[1], $m[2]]);
            $count++;
        }
    }
    $msg = "Added $count payments from list.";
}

// ---------- csv upload ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv']) && is_uploaded_file($_FILES['csv']['tmp_name'])) {
    $ins = $pdo->prepare("INSERT INTO payments(wallet, amount) VALUES(?,?)");
    $count = 0;
    if (($h = fopen($_FILES['csv']['tmp_name'], 'r')) !== false) {
        while (($row = fgetcsv($h)) !== false) {
            if (isset($row[0], $row[1]) && preg_match('/^01\d{9}$/', trim($row[0]))) {
                $ins->execute([trim($row[0]), (float)$row[1]]);
                $count++;
            }
        }
        fclose($h);
    }
    $msg = "Imported $count rows from CSV.";
}

// ---------- retry / delete ----------
if (isset($_GET['retry'])) {
    $pdo->prepare("UPDATE payments SET status='pending', result=NULL WHERE id=? AND status='failed'")
        ->execute([(int)$_GET['retry']]);
    header('Location: ?'); exit;
}
if (isset($_GET['del'])) {
    $pdo->prepare("DELETE FROM payments WHERE id=?")->execute([(int)$_GET['del']]);
    header('Location: ?'); exit;
}

$status = $_GET['status'] ?? 'pending';
if (!in_array($status, ['pending','processing','done','failed','all'], true)) $status = 'pending';

page_top('AutoPay Admin');
echo "<div class='nav'><b>AutoPay Admin Panel</b><br><br>
<a href='?status=pending'>Pending</a> | <a href='?status=processing'>Processing</a> |
<a href='?status=done'>Done</a> | <a href='?status=failed'>Failed</a> | <a href='?status=all'>All</a>
<a href='?logout=1' style='float:right'>Logout</a></div>";

if ($msg) echo "<p style='color:#4ade80'>".e($msg)."</p>";

echo "<h3>Add payment list</h3>
<form method='post'>
<textarea name='list' rows='6' placeholder='01719554634-1000&#10;01763636365-3500&#10;01636353655-500'></textarea>
<p style='color:#94a3b8;font-size:12px'>Format: wallet-amount or wallet,amount — one per line</p>
<br><br><button name='add_text' value='1'>Add list</button>
</form>
<form method='post' enctype='multipart/form-data' style='margin-top:10px'>
<input type='file' name='csv' accept='.csv' style='width:auto'>
<button>Upload CSV (wallet,amount)</button>
</form>";

$where = $status === 'all' ? '1=1' : "status='".$status."'";
$rows = $pdo->query("SELECT * FROM payments WHERE $where ORDER BY id ASC LIMIT 500")->fetchAll();

echo "<h3>Status: ".e($status)." (".count($rows).")</h3>
<table><tr><th>ID</th><th>Wallet</th><th>Amount</th><th>Status</th><th>Result</th><th>Created</th><th></th></tr>";
foreach ($rows as $r) {
    $res = function_exists('mb_strimwidth') ? mb_strimwidth((string)$r['result'], 0, 90, '...') : substr((string)$r['result'], 0, 90);
    echo "<tr><td>".(int)$r['id']."</td><td>".e($r['wallet'])."</td><td>".e($r['amount'])."</td>
    <td><span class='pill ".e($r['status'])."'>".e($r['status'])."</span></td>
    <td>".e($res)."</td><td>".e($r['created_at'])."</td>
    <td>".($r['status'] === 'failed' ? "<a href='?retry=".(int)$r['id']."'>Retry</a> " : "")
    ."<a href='?del=".(int)$r['id']."' onclick="return confirm('Delete this row?')">Del</a></td></tr>";
}
echo "</table>";
page_bottom();
