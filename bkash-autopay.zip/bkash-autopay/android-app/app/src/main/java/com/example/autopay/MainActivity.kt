package com.example.autopay

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val etUrl = findViewById<EditText>(R.id.etUrl)
        val etKey = findViewById<EditText>(R.id.etKey)
        val etPin = findViewById<EditText>(R.id.etPin)
        val etCode = findViewById<EditText>(R.id.etCode)
        val tvLog = findViewById<TextView>(R.id.tvLog)

        etUrl.setText(prefs.getString("url", ""))
        etKey.setText(prefs.getString("key", ""))
        etPin.setText(prefs.getString("pin", ""))
        etCode.setText(prefs.getString("code", "*247#"))

        fun save() {
            prefs.edit()
                .putString("url", etUrl.text.toString().trim().removeSuffix("/"))
                .putString("key", etKey.text.toString().trim())
                .putString("pin", etPin.text.toString().trim())
                .putString("code", etCode.text.toString().trim())
                .apply()
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener { save() }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            save()
            checkPerms()
            LogBus.log("Starting worker...")
            ContextCompat.startForegroundService(this, Intent(this, PayService::class.java))
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, PayService::class.java))
            LogBus.log("Stopped.")
        }

        scope.launch {
            LogBus.lines.collect { line ->
                tvLog.text = line
            }
        }
    }

    private fun checkPerms() {
        val need = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.CALL_PHONE)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) ActivityCompat.requestPermissions(this, need.toTypedArray(), 1)
    }
}
