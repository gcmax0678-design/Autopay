package com.example.autopay

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Accessibility service that watches the phone/USSD dialog and fills in
 * the inputs queued by PayEngine:  1 -> wallet -> amount -> 1 -> PIN
 */
class UssdService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        PayEngine.connected = true
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        PayEngine.connected = false
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return

        if (isPhoneUi(pkg)) {
            val root = rootInActiveWindow ?: return
            val text = flattenText(root)
            if (text.isNotBlank()) PayEngine.lastDialogText = text

            // hard-stop words: end this payment immediately and report what we saw
            val lower = text.lowercase()
            val isFail = lower.contains("incorrect") || lower.contains("wrong") ||
                lower.contains("insufficient") || lower.contains("not have") ||
                lower.contains("failed") || lower.contains("block") ||
                lower.contains("limit") || lower.contains("maximum")
            if (isFail) {
                // dismiss the dialog so the next payment can start, then report
                clickButton(root, listOf("OK", "Ok", "ওকে", "Cancel"))
                PayEngine.complete()
                return
            }

            // success screen ("Send Money ... successful. TrxID ...") with an OK
            // button: press it so the session closes cleanly, then finish.
            if (PayEngine.active && PayEngine.queue.isEmpty() &&
                (lower.contains("successful") || lower.contains("trxid"))
            ) {
                clickButton(root, listOf("OK", "Ok", "ওকে"))
                PayEngine.complete()
                return
            }

            if (!PayEngine.active || PayEngine.queue.isEmpty()) return
            val input = PayEngine.queue.removeAt(0)

            handler.postDelayed({
                val r = rootInActiveWindow ?: run {
                    PayEngine.queue.add(0, input); return@postDelayed
                }
                val edit = findEditText(r)
                if (edit == null) {
                    PayEngine.queue.add(0, input); return@postDelayed
                }
                val args = Bundle().apply {
                    putCharSequence(
                        AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                        input
                    )
                }
                edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                handler.postDelayed({
                    val r2 = rootInActiveWindow ?: run {
                        PayEngine.queue.add(0, input); return@postDelayed
                    }
                    val send = findButton(r2, listOf("Send", "OK", "Ok", "ওকে", "পাঠান", "Confirm"))
                    if (send != null) {
                        send.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    } else {
                        PayEngine.queue.add(0, input)
                    }
                }, 500)
            }, 600)
        } else {
            // another app/window came to the front => the USSD dialog closed
            if (PayEngine.active) PayEngine.complete()
        }
    }

    private fun isPhoneUi(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("phone") || p.contains("telecom")
    }

    private fun flattenText(node: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo) {
            n.text?.let { sb.append(it).append(' ') }
            for (i in 0 until n.childCount) {
                n.getChild(i)?.let { walk(it) }
            }
        }
        walk(node)
        return sb.toString().trim()
    }

    private fun findEditText(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.className?.toString() == "android.widget.EditText" && node.isEditable) return node
        for (i in 0 until node.childCount) {
            val r = node.getChild(i)?.let { findEditText(it) }
            if (r != null) return r
        }
        return null
    }

    /** Finds a button by label and clicks it (used to dismiss dialogs). */
    private fun clickButton(node: AccessibilityNodeInfo, labels: List<String>): Boolean {
        val b = findButton(node, labels) ?: return false
        return b.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun findButton(node: AccessibilityNodeInfo, labels: List<String>): AccessibilityNodeInfo? {
        val t = node.text?.toString()?.trim()
        if (t != null && labels.any { it.equals(t, ignoreCase = true) } && node.isClickable) return node
        for (i in 0 until node.childCount) {
            val r = node.getChild(i)?.let { findButton(it, labels) }
            if (r != null) return r
        }
        return null
    }

    override fun onInterrupt() {}
}
