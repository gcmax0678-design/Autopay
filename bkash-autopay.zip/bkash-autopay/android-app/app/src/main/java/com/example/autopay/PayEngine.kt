package com.example.autopay

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Shared state between the USSD accessibility service and the payment worker.
 * The worker pushes the menu inputs (option -> wallet -> amount -> confirm -> PIN),
 * the service types them into the USSD dialog one window at a time.
 */
object PayEngine {
    @Volatile var active = false
    @Volatile var connected = false   // accessibility service running?
    @Volatile var lastDialogText = ""
    var queue = mutableListOf<String>()

    private var deferred: CompletableDeferred<String>? = null

    fun start(inputs: List<String>): CompletableDeferred<String> {
        queue = inputs.toMutableList()
        lastDialogText = ""
        active = true
        deferred = CompletableDeferred()
        return deferred!!
    }

    fun complete() {
        if (!active) return
        active = false
        deferred?.complete(lastDialogText.ifBlank { "finished (no message captured)" })
    }

    fun fail(reason: String) {
        active = false
        deferred?.complete(reason)
    }
}

/** Simple log bus so the UI can show live progress. */
object LogBus {
    val lines = MutableStateFlow("")
    fun log(s: String) {
        val stamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
            .format(java.util.Date())
        lines.value = (lines.value + "[$stamp] $s\n").takeLast(4000)
    }
}
