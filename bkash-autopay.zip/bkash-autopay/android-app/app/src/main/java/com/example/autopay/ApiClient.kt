package com.example.autopay

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Minimal JSON API client for the admin panel. */
object ApiClient {
    var base = ""
    var key = ""

    fun getJson(path: String): JSONObject {
        val c = URL(base + path).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.setRequestProperty("X-API-Key", key)
        val body = try {
            c.inputStream.bufferedReader().readText()
        } catch (t: Throwable) {
            val err = c.errorStream?.bufferedReader()?.readText()
            throw RuntimeException("HTTP ${c.responseCode}: $err")
        }
        return JSONObject(body)
    }

    fun postJson(path: String, json: JSONObject): JSONObject {
        val c = URL(base + path).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("X-API-Key", key)
        c.outputStream.use { it.write(json.toString().toByteArray()) }
        val body = try {
            c.inputStream.bufferedReader().readText()
        } catch (t: Throwable) {
            val err = c.errorStream?.bufferedReader()?.readText()
            throw RuntimeException("HTTP ${c.responseCode}: $err")
        }
        return JSONObject(body)
    }
}
