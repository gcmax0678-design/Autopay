package com.example.autopay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject

/**
 * Foreground worker:
 * 1. asks the panel for the next pending payment
 * 2. dials the USSD code and lets UssdService drive the menus
 * 3. reports success/failure back to the panel
 */
class PayService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var running = false
    private lateinit var prefs: SharedPreferences
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val ch = NotificationChannel("autopay", "AutoPay", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)

        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, "autopay")
            .setContentTitle("AutoPay is running")
            .setContentText("Processing withdrawal queue...")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        startForeground(1, n)

        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "autopay:worker")
        wakeLock?.acquire(10 * 60 * 1000L)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!running) {
            running = true
            scope.launch { loop() }
        }
        return START_STICKY
    }

    private suspend fun loop() {
        while (running) {
            wakeLock?.acquire(10 * 60 * 1000L) // keep the CPU alive
            try {
                ApiClient.base = prefs.getString("url", "")!!.trim().removeSuffix("/")
                ApiClient.key = prefs.getString("key", "")!!.trim()
                if (ApiClient.base.isEmpty() || ApiClient.key.isEmpty()) {
                    LogBus.log("ERROR: set Panel URL and API key in the app first!")
                    delay(15000); continue
                }

                val item = ApiClient.getJson("/?action=next")
                if (!item.has("id")) {
                    delay(30000) // queue empty -> check again in 30s
                    continue
                }

                val id = item.getInt("id")
                val wallet = item.getString("wallet")
                val amount = item.getString("amount")
                LogBus.log("Paying #$id -> $wallet  Tk$amount")

                val message = pay(wallet, amount, id)
                val ok = message.contains("success", ignoreCase = true)

                val report = JSONObject()
                    .put("id", id)
                    .put("success", ok)
                    .put("message", message.take(400))
                ApiClient.postJson("/?action=report", report)

                LogBus.log("Result #$id: ${if (ok) "PAID" else "FAILED"} - $message")

                // human-like pause between payments
                delay((8000..20000).random().toLong())
            } catch (t: Throwable) {
                LogBus.log("ERROR: ${t.message}")
                delay(20000)
            }
        }
    }

    /**
     * Runs one full USSD payment. Returns the final USSD message.
     *
     * Flow (matches the *247# menus):
     *   1          -> Send Money
     *   wallet     -> receiver bKash account no
     *   amount     -> Tk amount
     *   id         -> Reference (we use the payment ID from the panel)
     *   pin        -> Menu PIN to confirm
     */
    private suspend fun pay(wallet: String, amount: String, id: Int): String {
        val pin = prefs.getString("pin", "") ?: ""
        if (pin.isEmpty()) return "ERROR: PIN not set in the app"
        if (!PayEngine.connected) return "ERROR: enable the AutoPay accessibility service"

        val code = (prefs.getString("code", "*247#") ?: "*247#").replace("#", "%23")
        val deferred = PayEngine.start(listOf("1", wallet, amount, id.toString(), pin))

        val call = Intent(Intent.ACTION_CALL, Uri.parse("tel:$code"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(call)

        return withTimeoutOrNull(120000) { deferred.await() }
            ?: run { PayEngine.fail("TIMEOUT"); "TIMEOUT (USSD session stuck)" }
    }

    override fun onDestroy() {
        running = false
        scope.cancel()
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
